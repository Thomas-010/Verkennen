function welkom(){ 
    window.alert('Welkom op deze pagina')
    document.getElementById('welkom').innerHTML = "doei"
}
